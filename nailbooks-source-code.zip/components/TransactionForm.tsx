
import React, { useState, useEffect } from 'react';
import { Staff, TransactionType, PaymentMethod, AppSettings, TransactionStaffDetail } from '../types';
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES } from '../constants';
import { PlusCircle, Loader2, Camera, Calendar, Coins, UserPlus, Trash2, X, AlertCircle, Banknote, CreditCard, Wallet, Sparkles } from 'lucide-react';
import { parseTransactionWithGemini } from '../services/geminiService';

interface Props {
  onAdd: (data: any) => void;
  staffList: Staff[];
  settings: AppSettings;
}

export const TransactionForm: React.FC<Props> = ({ onAdd, staffList }) => {
  const [loading, setLoading] = useState(false);
  
  // Basic Info
  const [type, setType] = useState<TransactionType>('INCOME');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState(INCOME_CATEGORIES[0]);
  const [desc, setDesc] = useState('');
  
  // Payment Inputs (Combined Row)
  const [cashAmount, setCashAmount] = useState('');
  const [nonCashAmount, setNonCashAmount] = useState('');
  const [nonCashType, setNonCashType] = useState<PaymentMethod>('CARD'); // Default non-cash type

  // Totals & Details
  const [totalTip, setTotalTip] = useState('');
  const [tax, setTax] = useState('');
  const [staffEntries, setStaffEntries] = useState<TransactionStaffDetail[]>([]);

  // Calculated Total
  const totalAmount = (parseFloat(cashAmount) || 0) + (parseFloat(nonCashAmount) || 0);
  
  // Helper to add a row
  const addStaffRow = (initialData?: Partial<TransactionStaffDetail>) => {
    setStaffEntries(prev => [...prev, { staffId: '', amount: 0, tip: 0, ...initialData }]);
  };

  const removeStaffRow = (index: number) => {
    const newEntries = [...staffEntries];
    newEntries.splice(index, 1);
    setStaffEntries(newEntries);
  };

  const updateStaffRow = (index: number, field: keyof TransactionStaffDetail, value: any) => {
    const newEntries = [...staffEntries];
    newEntries[index] = { ...newEntries[index], [field]: value };
    setStaffEntries(newEntries);
  };

  // Auto-fill amounts from Staff Entries (Optional - if user enters staff details first)
  useEffect(() => {
    if (type === 'INCOME' && staffEntries.length > 0) {
        // Only auto-sum if user hasn't manually entered a total yet (basic heuristic)
        // or just calculate sum for validation. 
        // Let's NOT auto-overwrite main inputs to avoid fighting the user.
    }
  }, [staffEntries, type]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const valCash = parseFloat(cashAmount) || 0;
    const valNonCash = parseFloat(nonCashAmount) || 0;
    const valTotal = valCash + valNonCash;
    const valTip = parseFloat(totalTip) || 0;
    const valTax = parseFloat(tax) || 0;

    if (valTotal === 0 && type === 'INCOME') return alert("Vui lòng nhập số tiền");

    // Determine final method
    let finalMethod: PaymentMethod = 'CASH';
    if (valCash > 0 && valNonCash > 0) finalMethod = 'OTHER'; // Mixed
    else if (valNonCash > 0) finalMethod = nonCashType;
    else finalMethod = 'CASH';

    // Clean up staff entries
    const validDetails = staffEntries.filter(s => s.staffId !== '');
    const validStaffIds = validDetails.map(s => s.staffId);

    onAdd({
      id: Math.random().toString(36).substr(2, 9),
      type,
      date: new Date(date).toISOString(),
      amount: valTotal,
      tip: valTip,
      tax: valTax,
      category,
      description: desc || (type === 'INCOME' ? 'Doanh thu dịch vụ' : 'Chi phí hoạt động'),
      paymentMethod: finalMethod,
      paymentSplit: { cash: valCash, card: valNonCash }, // 'card' property stores the non-cash portion
      staffIds: validStaffIds,
      staffDetails: validDetails
    });

    // Reset fields
    setCashAmount('');
    setNonCashAmount('');
    setTotalTip('');
    setTax('');
    setDesc('');
    setStaffEntries([]);
  };

  const handleAI = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    
    // Prepare Staff Context
    const staffNames = staffList.map(s => s.name).join(', ');

    const reader = new FileReader();
    reader.onload = async (evt) => {
      const base64 = evt.target?.result as string;
      
      // Call Smarter AI Service
      const res = await parseTransactionWithGemini("Analyze this receipt", base64, staffNames);
      
      if (res) {
        // 1. Basic Info
        if (res.type) setType(res.type as any);
        if (res.category) setCategory(res.category);
        if (res.description) setDesc(res.description);
        if (res.date) setDate(res.date);
        
        // 2. Financials & Split Payment Logic (SMART FIX)
        const aiTotal = res.totalAmount || 0;
        const aiCash = res.split?.cash || 0;
        const aiCard = res.split?.card || 0;

        if (aiTotal > 0 && aiCash > 0 && Math.abs(aiCash + aiCard - aiTotal) > 1) {
            // Case: AI returned Total (262) and Cash (58.99) but Card is wrong (e.g. 0 or equal to Total).
            // Fix: Force Card = Total - Cash
            const calculatedCard = aiTotal - aiCash;
            setCashAmount(aiCash.toString());
            setNonCashAmount(calculatedCard > 0 ? calculatedCard.toFixed(2) : '0');
        } else if (res.split && (aiCash > 0 || aiCard > 0)) {
            // Case: AI Split seems correct (Sum matches Total)
            setCashAmount(aiCash.toString());
            setNonCashAmount(aiCard.toString());
        } else {
            // Fallback: Single Payment Method detected
            if (res.paymentMethod === 'CASH') {
                setCashAmount(aiTotal.toString());
                setNonCashAmount('0');
            } else {
                setNonCashAmount(aiTotal.toString());
                setCashAmount('0');
                if(res.paymentMethod) setNonCashType(res.paymentMethod as any);
            }
        }

        // 3. Tip & Tax
        if (res.tip) setTotalTip(res.tip.toString());
        if (res.tax) setTax(res.tax.toString());

        // 4. Smart Staff Matching
        if (res.staffGuess && Array.isArray(res.staffGuess) && res.staffGuess.length > 0) {
            const newEntries: TransactionStaffDetail[] = [];
            
            res.staffGuess.forEach((guess: any) => {
                // Find matching staff in our DB (fuzzy match by name inclusion)
                const matchedStaff = staffList.find(s => 
                    guess.name && s.name.toLowerCase().includes(guess.name.toLowerCase())
                );

                if (matchedStaff) {
                    newEntries.push({
                        staffId: matchedStaff.id,
                        amount: guess.amount || 0,
                        tip: guess.tip || 0
                    });
                }
            });

            if (newEntries.length > 0) {
                setStaffEntries(newEntries);
            }
        }
      } else {
        alert("Không đọc được ảnh hoặc ảnh quá mờ.");
      }
      setLoading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm mb-6 animate-fade-in relative overflow-hidden">
      {/* AI Processing Overlay */}
      {loading && (
        <div className="absolute inset-0 bg-white/80 z-20 flex flex-col items-center justify-center backdrop-blur-sm">
            <Loader2 size={48} className="text-indigo-600 animate-spin mb-4"/>
            <p className="text-indigo-900 font-bold text-lg animate-pulse">Đang phân tích ticket...</p>
            <p className="text-slate-500 text-sm">Đang tính toán Cash/Card & chia tiền</p>
        </div>
      )}

      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-slate-800 text-lg">Tạo Giao Dịch Mới (Ticket)</h3>
        <label className="flex items-center gap-2 cursor-pointer bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:shadow-lg hover:scale-105 transition-all">
           <Sparkles size={16} />
           <span>Smart Scan</span>
           <input type="file" accept="image/*" className="hidden" onChange={handleAI} disabled={loading} />
        </label>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Toggle Type */}
        <div className="flex gap-2 bg-slate-100 p-1 rounded-lg w-full md:w-1/2">
            <button type="button" onClick={() => setType('INCOME')} className={`flex-1 py-2 rounded-md text-sm font-bold transition-all ${type === 'INCOME' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'}`}>Income (Thu)</button>
            <button type="button" onClick={() => setType('EXPENSE')} className={`flex-1 py-2 rounded-md text-sm font-bold transition-all ${type === 'EXPENSE' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500'}`}>Expense (Chi)</button>
        </div>

        {/* --- MAIN INPUTS ROW (CASH & CARD) --- */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
             <div className="flex gap-4 items-end mb-2">
                 {/* Cash Input */}
                 <div className="flex-1">
                     <label className="block text-xs font-bold text-emerald-600 mb-1 flex items-center gap-1">
                         <Banknote size={14}/> Tiền Mặt (Cash)
                     </label>
                     <input 
                        type="number" 
                        value={cashAmount} 
                        onChange={e => setCashAmount(e.target.value)}
                        className="w-full p-3 border border-emerald-200 rounded-lg font-bold text-emerald-700 text-lg outline-none focus:ring-2 focus:ring-emerald-500 bg-white" 
                        placeholder="0.00"
                     />
                 </div>

                 {/* Non-Cash Input */}
                 <div className="flex-1">
                     <label className="block text-xs font-bold text-indigo-600 mb-1 flex items-center justify-between">
                         <div className="flex items-center gap-1"><CreditCard size={14}/> {nonCashType === 'BANK_TRANSFER' ? 'Bank' : nonCashType}</div>
                         {/* Mini Dropdown to change type */}
                         <select 
                            value={nonCashType} 
                            onChange={e => setNonCashType(e.target.value as PaymentMethod)}
                            className="text-[10px] font-normal bg-indigo-50 border border-indigo-100 rounded px-1 py-0.5 outline-none cursor-pointer"
                         >
                             <option value="CARD">Card</option>
                             <option value="CHECK">Check</option>
                             <option value="BANK_TRANSFER">Bank Acc</option>
                             <option value="CREDIT">Credit</option>
                         </select>
                     </label>
                     <input 
                        type="number" 
                        value={nonCashAmount} 
                        onChange={e => setNonCashAmount(e.target.value)}
                        className="w-full p-3 border border-indigo-200 rounded-lg font-bold text-indigo-700 text-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white" 
                        placeholder="0.00"
                     />
                 </div>
             </div>
             
             {/* Total Display */}
             <div className="text-right text-sm font-medium text-slate-500 flex justify-end items-center gap-2">
                 <span>Tổng Bill:</span>
                 <span className="text-xl font-black text-slate-900">${totalAmount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
             </div>
        </div>

        {/* --- DETAILS (DATE, TIP, TAX) --- */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <div className="col-span-1">
                <label className="block text-xs font-bold text-slate-500 mb-1">Ngày (Date)</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-2.5 border border-slate-200 rounded-lg outline-none bg-white text-sm" />
             </div>
             
             {type === 'INCOME' && (
                <>
                <div className="col-span-1">
                    <label className="block text-xs font-bold text-orange-500 mb-1">Tip Thợ</label>
                    <input 
                        type="number" 
                        value={totalTip} 
                        onChange={e => setTotalTip(e.target.value)}
                        className="w-full p-2.5 border border-orange-200 bg-orange-50 rounded-lg font-bold text-orange-600 text-sm outline-none" 
                        placeholder="0.00"
                    />
                </div>
                <div className="col-span-1">
                    <label className="block text-xs font-bold text-slate-400 mb-1">Thuế (Tax)</label>
                    <input 
                        type="number" 
                        value={tax} 
                        onChange={e => setTax(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 rounded-lg text-slate-600 text-sm outline-none" 
                        placeholder="0.00"
                    />
                </div>
                </>
             )}
        </div>

        {/* --- DYNAMIC STAFF ENTRY FOR INCOME --- */}
        {type === 'INCOME' && (
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Chi Tiết Thợ (Split)</label>
                    <button type="button" onClick={() => addStaffRow()} className="text-xs flex items-center gap-1 font-bold text-indigo-600 hover:bg-indigo-50 px-2 py-1 rounded">
                        <UserPlus size={14}/> Thêm Thợ
                    </button>
                </div>
                
                {staffEntries.length === 0 && (
                    <div className="text-center py-4 text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-lg cursor-pointer hover:border-indigo-300 hover:bg-white transition-colors" onClick={() => addStaffRow()}>
                        Chưa có thợ nào. Nhấn để thêm thợ.
                    </div>
                )}

                <div className="space-y-2">
                    {staffEntries.map((entry, idx) => (
                        <div key={idx} className="flex gap-2 items-center animate-fade-in">
                            <select 
                                value={entry.staffId}
                                onChange={(e) => updateStaffRow(idx, 'staffId', e.target.value)}
                                className="flex-[2] p-2 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                            >
                                <option value="">Chọn Thợ...</option>
                                {staffList.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                            </select>

                            <div className="flex-1 relative">
                                <span className="absolute left-2 top-2 text-slate-400 text-xs">$</span>
                                <input 
                                    type="number" 
                                    placeholder="Svc"
                                    value={entry.amount || ''}
                                    onChange={(e) => updateStaffRow(idx, 'amount', parseFloat(e.target.value))}
                                    className="w-full p-2 pl-4 border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                                />
                            </div>

                            <div className="flex-1 relative">
                                <span className="absolute left-2 top-2 text-slate-400 text-xs text-orange-400"><Coins size={10}/></span>
                                <input 
                                    type="number" 
                                    placeholder="Tip"
                                    value={entry.tip || ''}
                                    onChange={(e) => updateStaffRow(idx, 'tip', parseFloat(e.target.value))}
                                    className="w-full p-2 pl-6 border border-orange-200 bg-orange-50 rounded-lg text-sm font-medium text-orange-700 focus:ring-2 focus:ring-orange-500 outline-none"
                                />
                            </div>

                            <button type="button" onClick={() => removeStaffRow(idx)} className="p-2 text-rose-400 hover:bg-rose-100 rounded-lg">
                                <Trash2 size={16}/>
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        )}

        <div className="flex gap-4">
             <div className="flex-[2]">
                <label className="block text-xs font-bold text-slate-500 mb-1">Ghi Chú</label>
                <input value={desc} onChange={e => setDesc(e.target.value)} placeholder={type === 'INCOME' ? "Walk-in..." : "Tiền nhà..."} className="w-full p-2.5 border border-slate-200 rounded-lg outline-none text-sm" />
             </div>
             <div className="flex-1">
                <label className="block text-xs font-bold text-slate-500 mb-1">Hạng Mục</label>
                <select value={category} onChange={e => setCategory(e.target.value)} className="w-full p-2.5 border border-slate-200 rounded-lg bg-white outline-none text-sm">
                {(type === 'INCOME' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
             </div>
        </div>

        <button type="submit" className={`w-full py-4 rounded-xl font-bold text-white shadow-lg flex justify-center items-center gap-2 text-lg transition-transform active:scale-[0.99] ${type === 'INCOME' ? 'bg-slate-900 hover:bg-slate-800 shadow-slate-200' : 'bg-rose-600 hover:bg-rose-700 shadow-rose-200'}`}>
          <PlusCircle size={20} /> 
          {type === 'INCOME' ? `Tạo Bill ($${totalAmount})` : 'Ghi Nhận Chi Phí'}
        </button>
      </form>
    </div>
  );
};
