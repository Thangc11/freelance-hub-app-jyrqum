
import { Staff, AppSettings } from './types';

export const INCOME_CATEGORIES = [
  'Doanh Thu Bán Hàng (Sales)',
  'Doanh Thu Dịch Vụ (Service)',
  'Doanh Thu Dự Án (Project)',
  'Thu Nhập Khác (Other)',
  'Đầu Tư (Investment)',
  'Hoàn Tiền (Refund)'
];

export const EXPENSE_CATEGORIES = [
  'Nhập Hàng (COGS)',
  'Tiền Thuê (Rent/Office)',
  'Lương Nhân Viên (Payroll)',
  'Marketing & Ads',
  'Phần Mềm & Tiện Ích (SaaS/Utilities)',
  'Đi Lại & Ăn Uống (Travel/Meals)',
  'Thuế (Tax)',
  'Bảo Trì & Sửa Chữa',
  'Chi Phí Khác'
];

export const INITIAL_STAFF: Staff[] = [
  { 
      id: 'admin', 
      name: 'Administrator', 
      role: 'Owner', 
      commissionRate: 0, 
      salary: 0, 
      checkPayoutRate: 0,
      employmentType: 'Contract'
  }
];

export const DEFAULT_SETTINGS: AppSettings = {
  salonName: 'My Business',
  defaultTaxRate: 0
};
