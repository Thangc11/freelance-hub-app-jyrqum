
const CACHE_NAME = 'nailbooks-cache-v1';

// List of files to cache immediately
const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_URLS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  // Clean up old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests like Google GenAI API to avoid opaque response issues in strict mode, 
  // EXCEPT for the specific CDNs we need.
  const url = new URL(event.request.url);
  
  // Strategy: Stale-While-Revalidate
  // Try to serve from cache first, then update from network in background
  if (event.request.method === 'GET') {
      event.respondWith(
        caches.open(CACHE_NAME).then((cache) => {
          return cache.match(event.request).then((response) => {
            const fetchPromise = fetch(event.request).then((networkResponse) => {
              // Only cache valid responses
              if (networkResponse.ok) {
                  cache.put(event.request, networkResponse.clone());
              }
              return networkResponse;
            }).catch(() => {
                // Network failed, nothing to do here, hope it's in cache
            });
            return response || fetchPromise;
          });
        })
      );
  }
});
