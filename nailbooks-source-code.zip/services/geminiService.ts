
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
// Sử dụng model Flash 2.5 hoặc Pro 3 Vision để nhận diện ảnh tốt nhất
const MODEL_NAME = "gemini-3-flash-preview"; 

export const parseTransactionWithGemini = async (text: string, imageBase64?: string, staffContext?: string) => {
  try {
    const prompt = `
      You are an expert accountant for a Nail Salon. Your job is to digitize receipts with STRICT MATHEMATICAL LOGIC.
      
      CONTEXT:
      - Current Date: ${new Date().toISOString()}
      - Known Staff: [${staffContext || 'None'}]

      CRITICAL RULES FOR PARSING:
      1. Find the **GRAND TOTAL** (Final Bill Amount).
      2. Find the **CASH** amount paid.
      3. **CALCULATE THE CARD AMOUNT**:
         - IF (Total exists) AND (Cash exists) AND (Card is not explicitly stated):
           -> CARD = GRAND TOTAL - CASH.
         - Example: Ticket shows Total $262 and Cash $58.99.
           -> Result: Total=$262, Cash=$58.99, Card=$203.01.
           -> DO NOT return Card=$262.
         - IF "Cash Tendered" (Khách đưa) is found, look for "Change" (Thối lại). Real Cash = Tendered - Change.

      4. TIP & TAX:
         - Tip is usually separate. If handwritten "Tip: 10", add it to the 'tip' field.
      
      RETURN JSON ONLY:
      {
        "type": "INCOME",
        "date": "YYYY-MM-DD",
        "totalAmount": number (The Grand Total detected on receipt),
        "tip": number,
        "tax": number,
        "paymentMethod": "CASH" | "CARD" | "OTHER",
        "split": { 
            "cash": number (The explicitly extracted cash amount), 
            "card": number (The calculated remaining amount: Total - Cash) 
        },
        "category": "Doanh Thu Dịch Vụ",
        "description": string,
        "staffGuess": [ { "name": string, "amount": number, "tip": number } ]
      }
    `;

    const parts: any[] = [{ text: prompt }];
    if (text) parts.push({ text: `Additional Notes: ${text}` });
    
    if (imageBase64) {
      const base64Data = imageBase64.split(',')[1];
      parts.push({
        inlineData: { mimeType: "image/jpeg", data: base64Data }
      });
    }

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { role: "user", parts },
      config: { responseMimeType: "application/json" }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Parse Error:", error);
    return null;
  }
};

export const getBusinessInsights = async (summaryData: string, question: string) => {
  try {
    const prompt = `
      Act as a CFO/Business Analyst for a Nail Salon.
      Financial Summary Data: ${summaryData}
      User Question: "${question}"
      Answer in Vietnamese. Be concise, strategic, and focus on cash flow and profitability.
    `;
    
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt
    });

    return response.text;
  } catch (error) {
    return "Không thể kết nối với AI lúc này.";
  }
};
