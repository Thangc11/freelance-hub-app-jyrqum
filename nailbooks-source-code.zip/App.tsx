
import React, { useState, useEffect } from 'react';
import { Transaction, Staff, AppSettings } from './types';
import { INITIAL_STAFF, DEFAULT_SETTINGS } from './constants';
import { SummaryCards } from './components/SummaryCards';
import { TransactionForm } from './components/TransactionForm';
import { TransactionsList } from './components/TransactionsList';
import { StaffManager } from './components/StaffManager';
import { Analytics } from './components/Analytics';
import { TaxPrep } from './components/TaxPrep';
import { SettingsAndData } from './components/SettingsAndData';
import { LayoutDashboard, Receipt, Users, PieChart, Settings, Menu, X, AlertTriangle, Briefcase, PlusCircle, List, ArrowRight, FileText, TrendingUp, ShieldCheck } from 'lucide-react';

interface ErrorBoundaryProps {
  children?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  render() {
    if (this.state.hasError) return (
      <div className="p-10 text-center">
        <AlertTriangle className="mx-auto text-red-500 mb-4" size={48}/>
        <h1 className="text-xl font-bold mb-2">Lỗi Hệ Thống</h1>
        <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="bg-slate-900 text-white px-4 py-2 rounded">Reset App</button>
      </div>
    );
    return (this as any).props.children;
  }
}

function BizManagerApp() {
  const [tab, setTab] = useState('DASHBOARD');
  const [menuOpen, setMenuOpen] = useState(false);
  const [txTab, setTxTab] = useState<'FORM' | 'LIST'>('FORM');
  const [reportTab, setReportTab] = useState<'FINANCIALS' | 'TAX'>('FINANCIALS');

  const useStorage = <T,>(key: string, init: T): [T, (v: T) => void] => {
    const [val, setVal] = useState<T>(() => {
      try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : init;
      } catch { return init; }
    });
    useEffect(() => localStorage.setItem(key, JSON.stringify(val)), [key, val]);
    return [val, setVal];
  };

  const [transactions, setTx] = useStorage<Transaction[]>('bm_tx', []);
  const [staff, setStaff] = useStorage<Staff[]>('bm_staff', INITIAL_STAFF);
  const [settings, setSettings] = useStorage<AppSettings>('bm_settings', DEFAULT_SETTINGS);

  const addTx = (t: Transaction) => setTx([t, ...transactions]);
  const delTx = (id: string) => setTx(transactions.filter(t => t.id !== id));
  
  const Nav = ({ id, icon: Icon, label }: any) => (
    <button 
      onClick={() => { setTab(id); setMenuOpen(false); }} 
      className={`flex items-center space-x-3 w-full p-3 rounded-xl mb-1 transition-colors ${tab === id ? 'bg-slate-900 text-white shadow-lg shadow-slate-300' : 'text-slate-500 hover:bg-slate-100'}`}
    >
      <Icon size={20} /> <span className="font-medium">{label}</span>
    </button>
  );

  return (
    <div className="flex min-h-screen bg-slate-100 font-sans text-slate-900">
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 transform ${menuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform lg:translate-x-0 lg:static`}>
        <div className="p-6">
           <div className="flex items-center gap-2 text-slate-900 mb-1">
             <div className="bg-slate-900 text-white p-1.5 rounded-lg"><Briefcase size={20} /></div>
             <h1 className="text-xl font-black tracking-tight">BizManager</h1>
           </div>
           <p className="text-xs text-slate-400 font-medium pl-1">Business Management</p>
        </div>
        <nav className="px-4">
          <Nav id="DASHBOARD" icon={LayoutDashboard} label="Tổng Quan" />
          <Nav id="TRANSACTIONS" icon={Receipt} label="Sổ Cái (Thu/Chi)" />
          <Nav id="STAFF" icon={Users} label="Nhân Sự & Lương" />
          <Nav id="REPORTS" icon={PieChart} label="Báo Cáo & Thuế" />
          <Nav id="SETTINGS" icon={Settings} label="Dữ Liệu" />
        </nav>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white h-16 border-b border-slate-200 flex items-center justify-between px-4 lg:hidden">
           <span className="font-bold text-slate-900 flex items-center gap-2"><Briefcase size={18}/> BizManager</span>
           <button onClick={() => setMenuOpen(!menuOpen)} className="p-2 text-slate-500">{menuOpen ? <X /> : <Menu />}</button>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          <div className="max-w-6xl mx-auto">
            {tab === 'DASHBOARD' && (
              <div className="space-y-6">
                <SummaryCards transactions={transactions} staffList={staff} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div onClick={() => { setTab('TRANSACTIONS'); setTxTab('FORM'); }} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:shadow-md transition-shadow flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-lg group-hover:bg-emerald-600 group-hover:text-white transition-colors"><PlusCircle size={24}/></div>
                            <div><h3 className="font-bold text-slate-800 text-lg">Tạo Bill Mới</h3><p className="text-slate-500 text-sm">Nhập doanh thu hoặc chi phí</p></div>
                        </div>
                        <ArrowRight size={20} className="text-slate-300 group-hover:text-emerald-600 transition-colors"/>
                    </div>
                    <div onClick={() => { setTab('STAFF'); }} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:shadow-md transition-shadow flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-indigo-100 text-indigo-600 rounded-lg group-hover:bg-indigo-600 group-hover:text-white transition-colors"><Users size={24}/></div>
                            <div><h3 className="font-bold text-slate-800 text-lg">Tính Lương</h3><p className="text-slate-500 text-sm">Xem bảng lương và quản lý thợ</p></div>
                        </div>
                        <ArrowRight size={20} className="text-slate-300 group-hover:text-indigo-600 transition-colors"/>
                    </div>
                </div>
              </div>
            )}
            
            {tab === 'TRANSACTIONS' && (
              <div className="space-y-6">
                 <div className="flex justify-center md:justify-start">
                    <div className="flex gap-1 p-1 bg-slate-200 rounded-lg">
                        <button onClick={() => setTxTab('FORM')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${txTab === 'FORM' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}><PlusCircle size={16}/> Tạo Giao Dịch</button>
                        <button onClick={() => setTxTab('LIST')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${txTab === 'LIST' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}><List size={16}/> Lịch Sử Giao Dịch</button>
                    </div>
                 </div>
                 {txTab === 'FORM' && <TransactionForm onAdd={(t) => { addTx(t); alert("Đã thêm thành công!"); }} staffList={staff} settings={settings} />}
                 {txTab === 'LIST' && <TransactionsList transactions={transactions} staffList={staff} onDelete={delTx} />}
              </div>
            )}

            {tab === 'STAFF' && <StaffManager staffList={staff} setStaffList={setStaff} transactions={transactions} />}
            
            {tab === 'REPORTS' && (
                <div className="space-y-6">
                     <div className="flex justify-center md:justify-start">
                        <div className="flex gap-1 p-1 bg-slate-200 rounded-lg">
                            <button onClick={() => setReportTab('FINANCIALS')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${reportTab === 'FINANCIALS' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}><TrendingUp size={16}/> Tài Chính & Lời Lỗ</button>
                            <button onClick={() => setReportTab('TAX')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${reportTab === 'TAX' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}><ShieldCheck size={16}/> Trung Tâm Thuế</button>
                        </div>
                     </div>
                    {reportTab === 'FINANCIALS' && <Analytics transactions={transactions} settings={settings} staffList={staff} />}
                    {reportTab === 'TAX' && <TaxPrep transactions={transactions} staffList={staff} />}
                </div>
            )}
            
            {tab === 'SETTINGS' && (
              <SettingsAndData data={{ transactions, staffList: staff, settings: settings }} onImport={(d) => { if (d.transactions) setTx(d.transactions); if (d.staffList) setStaff(d.staffList); if (d.settings) setSettings(d.settings); }} onReset={() => { localStorage.clear(); window.location.reload(); }} />
            )}
          </div>
        </div>
      </main>
      {menuOpen && <div className="fixed inset-0 bg-black/20 z-40 lg:hidden" onClick={() => setMenuOpen(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BizManagerApp />
    </ErrorBoundary>
  );
}
