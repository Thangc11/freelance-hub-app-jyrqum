
export type TransactionType = 'INCOME' | 'EXPENSE';

export type PaymentMethod = 'BANK_TRANSFER' | 'CASH' | 'CARD' | 'CHECK' | 'CREDIT' | 'OTHER';

export type StaffRole = 'Owner' | 'Manager' | 'Technician' | 'Receptionist' | 'Trainee';

export interface Staff {
  id: string;
  name: string;
  role: StaffRole;
  commissionRate: number; // 0.6 = 60%
  salary: number; // Lương cứng (nếu có)
  checkPayoutRate: number; // 0.8 = 80% trả bằng Check, 20% Cash
  employmentType: 'W2' | 'Contract'; // Explicit tax classification
}

export interface TransactionStaffDetail {
  staffId: string;
  amount: number; // Tiền service thợ này làm
  tip: number;    // Tiền tip thợ này nhận
}

export interface Transaction {
  id: string;
  date: string; // ISO String
  type: TransactionType;
  category: string;
  amount: number; // Tổng tiền bill (Service + Product)
  tip: number; // Tổng Tip
  tax: number;
  description: string;
  paymentMethod: PaymentMethod;
  paymentSplit?: {
    cash: number;
    card: number;
  };
  staffIds: string[]; // Deprecated logic (keep for backward compatibility if needed, mostly use staffDetails)
  staffDetails?: TransactionStaffDetail[]; // New logic: Detailed breakdown per staff
  receiptImage?: string; // Base64
}

export interface AppSettings {
  salonName: string;
  defaultTaxRate: number;
}
