
import React, { useState } from 'react';
import { Staff, Transaction, StaffRole } from '../types';
import { Trash2, Plus, User, Briefcase, BadgePercent, Wallet, Coins, CreditCard, Banknote, Users, Calculator, Settings, Calendar, Filter, FileText, BadgeCheck } from 'lucide-react';

interface Props {
  staffList: Staff[];
  setStaffList: (list: Staff[]) => void;
  transactions: Transaction[];
}

export const StaffManager: React.FC<Props> = ({ staffList, setStaffList, transactions }) => {
  const [activeTab, setActiveTab] = useState<'PAYROLL' | 'MANAGEMENT'>('PAYROLL');

  // Payroll Filter State
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // Mặc định đầu tháng
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Form State
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<StaffRole>('Technician');
  const [newCommission, setNewCommission] = useState('60'); // Nhập 60 cho 60%
  const [newCheckRate, setNewCheckRate] = useState('80'); // Mặc định trả 80% check, 20% Cash
  const [newEmpType, setNewEmpType] = useState<'W2' | 'Contract'>('Contract');

  const addStaff = () => {
    if (!newName) return;
    
    const commRate = parseFloat(newCommission) / 100;
    const checkRate = parseFloat(newCheckRate) / 100;

    setStaffList([...staffList, {
      id: Math.random().toString(36).substr(2, 9),
      name: newName,
      role: newRole,
      commissionRate: commRate,
      salary: 0,
      checkPayoutRate: checkRate,
      employmentType: newEmpType
    }]);
    
    // Reset form
    setNewName('');
    setNewCommission('60');
  };

  const removeStaff = (id: string) => {
    if (confirm('Xóa nhân viên này? Dữ liệu lịch sử giao dịch vẫn giữ nguyên nhưng sẽ không tính lương cho người này nữa.')) {
      setStaffList(staffList.filter(s => s.id !== id));
    }
  };

  const calculatePayroll = (staff: Staff) => {
    let totalService = 0;
    let tipTotal = 0;
    
    transactions.forEach(t => {
      // 1. Check Date Filter
      const tDate = t.date.split('T')[0];
      if (tDate < startDate || tDate > endDate) return;

      if (t.type === 'INCOME') {
        let amountToAdd = 0;
        let tipToAdd = 0;

        // Logic lấy tiền từng thợ
        if (t.staffDetails && t.staffDetails.length > 0) {
            const detail = t.staffDetails.find(d => d.staffId === staff.id);
            if (detail) {
                amountToAdd = (detail.amount || 0);
                tipToAdd = (detail.tip || 0);
            }
        } 
        // Fallback logic cũ
        else if (t.staffIds && t.staffIds.includes(staff.id)) {
            const split = t.staffIds.length;
            amountToAdd = t.amount / split;
            tipToAdd = (t.tip || 0) / split;
        }

        totalService += amountToAdd;
        tipTotal += tipToAdd;
      }
    });

    // 1. Tính tiền lương thợ được hưởng (Commission) trên TỔNG BILL
    const totalCommission = totalService * staff.commissionRate;

    // 2. Chia lương Check/Cash (Cách chủ trả cho thợ):
    // Dựa vào cài đặt của từng thợ (VD: Trả 80% check, 20% Cash)
    const commissionPayCheck = totalCommission * (staff.checkPayoutRate || 0);
    const commissionPayCash = totalCommission - commissionPayCheck;

    // Tổng thực lãnh (Gross Pay)
    // Tip thường đi vào Check (hoặc trả hết 1 cục tùy tiệm, ở đây mặc định cộng vào Check)
    const payByCheck = commissionPayCheck + tipTotal; 
    const payByCash = commissionPayCash;
    const grossTotal = payByCheck + payByCash;

    // 3. W-2 Specifics (Employer Cost)
    // Chủ tiệm phải đóng thêm ~7.65% (SS + Medicare) mà không trừ vào lương thợ.
    const employerTaxCost = staff.employmentType === 'W2' ? grossTotal * 0.0765 : 0;
    
    return { 
        totalService, 
        tipTotal,
        totalCommission,
        payByCheck,
        payByCash,
        grossTotal,
        employerTaxCost
    };
  };

  return (
    <div className="space-y-6">
      {/* --- TAB NAVIGATION --- */}
      <div className="flex justify-center md:justify-start">
        <div className="flex gap-1 p-1 bg-slate-200 rounded-lg">
            <button
                onClick={() => setActiveTab('PAYROLL')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'PAYROLL' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
                <Calculator size={16}/> Bảng Lương (Payroll)
            </button>
            <button
                onClick={() => setActiveTab('MANAGEMENT')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'MANAGEMENT' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
                <Users size={16}/> Quản Lý Thợ
            </button>
        </div>
      </div>

      {/* --- TAB 1: PAYROLL --- */}
      {activeTab === 'PAYROLL' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-fade-in">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="font-bold text-slate-700 flex items-center gap-2">
                   <Calculator size={20}/> Tính Lương (Payroll)
                </div>
                
                {/* Date Filter */}
                <div className="flex items-center gap-2 bg-white p-1.5 rounded-lg border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-1 text-slate-500 text-xs font-bold px-2">
                        <Filter size={14}/> Lọc:
                    </div>
                    <input 
                        type="date" 
                        value={startDate} 
                        onChange={e => setStartDate(e.target.value)} 
                        className="text-xs font-medium bg-slate-50 border border-slate-200 rounded px-2 py-1 outline-none text-slate-700"
                    />
                    <span className="text-slate-400 text-xs">➝</span>
                    <input 
                        type="date" 
                        value={endDate} 
                        onChange={e => setEndDate(e.target.value)} 
                        className="text-xs font-medium bg-slate-50 border border-slate-200 rounded px-2 py-1 outline-none text-slate-700"
                    />
                </div>
            </div>
            
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left border-collapse">
                <thead className="bg-slate-50 text-slate-500 border-b border-slate-200 whitespace-nowrap">
                    <tr>
                    <th className="p-4 font-semibold min-w-[180px]">Nhân Viên</th>
                    <th className="p-4 font-semibold text-right">Tổng Service</th>
                    <th className="p-4 font-semibold text-right text-orange-600">Tip</th>
                    <th className="p-4 font-semibold text-right bg-indigo-50/30 text-indigo-700">Lãnh Check</th>
                    <th className="p-4 font-semibold text-right bg-emerald-50/30 text-emerald-700">Lãnh Cash</th>
                    <th className="p-4 font-semibold text-right text-slate-700">Tổng (Gross)</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {staffList.map(s => {
                    const pay = calculatePayroll(s);
                    return (
                        <tr key={s.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="p-4">
                            <div className="font-bold text-slate-800 text-base flex items-center gap-2">
                                {s.name}
                                {s.employmentType === 'W2' ? (
                                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700 border border-purple-200">W-2</span>
                                ) : (
                                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700 border border-orange-200">1099</span>
                                )}
                            </div>
                            <div className="inline-flex items-center gap-1.5 mt-1 px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
                                <Briefcase size={12}/> {s.role} • {Math.round(s.commissionRate * 100)}%
                            </div>
                            {s.employmentType === 'W2' && (
                                <div className="mt-2 text-[10px] text-purple-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                                    +${Math.round(pay.employerTaxCost)} Employer Tax (Est)
                                </div>
                            )}
                        </td>
                        
                        {/* Total Service */}
                        <td className="p-4 text-right font-medium text-slate-800">
                            ${pay.totalService.toLocaleString('en-US')}
                        </td>
                        
                        {/* Tips */}
                        <td className="p-4 text-right font-bold text-orange-500">
                            +${pay.tipTotal.toLocaleString('en-US', {maximumFractionDigits: 0})}
                        </td>

                        {/* Final Pay Check */}
                        <td className="p-4 text-right bg-indigo-50/10 border-l border-slate-100">
                            <div className="text-indigo-700 font-bold text-base">
                                ${pay.payByCheck.toLocaleString('en-US', {maximumFractionDigits: 0})}
                            </div>
                            <div className="text-[10px] text-slate-400">{(s.checkPayoutRate * 100)}% + Tip</div>
                        </td>

                        {/* Final Pay Cash */}
                        <td className="p-4 text-right bg-emerald-50/10">
                            <div className="text-emerald-700 font-bold text-base">
                                ${pay.payByCash.toLocaleString('en-US', {maximumFractionDigits: 0})}
                            </div>
                            <div className="text-[10px] text-slate-400">{100 - (s.checkPayoutRate * 100)}% Comm</div>
                        </td>

                        {/* Gross Total */}
                        <td className="p-4 text-right font-black text-slate-900 border-l border-slate-200">
                            ${pay.grossTotal.toLocaleString('en-US', {maximumFractionDigits: 0})}
                            {s.employmentType === 'W2' && (
                                <div className="text-[10px] text-rose-500 font-normal mt-1">
                                    Chưa trừ thuế
                                </div>
                            )}
                        </td>
                        </tr>
                    );
                    })}
                    {staffList.length === 0 && (
                        <tr>
                            <td colSpan={6} className="p-8 text-center text-slate-400">Chưa có nhân viên nào.</td>
                        </tr>
                    )}
                </tbody>
                </table>
            </div>
            <div className="p-4 bg-yellow-50 text-yellow-800 text-xs flex items-start gap-2 border-t border-yellow-100">
                <BadgeCheck size={16} className="mt-0.5 shrink-0"/>
                <div>
                    <strong>Lưu ý về W-2:</strong> Số tiền hiển thị là "Lương gộp" (Gross Pay). 
                    Nếu nhân viên là W-2, bạn cần sử dụng dịch vụ Payroll (như Gusto, ADP) để khấu trừ thuế thu nhập cá nhân và đóng thuế Employer (FICA) trước khi viết check cho họ.
                </div>
            </div>
        </div>
      )}

      {/* --- TAB 2: MANAGEMENT --- */}
      {activeTab === 'MANAGEMENT' && (
        <div className="space-y-6 animate-fade-in">
             {/* Add Staff Form */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <User size={20} className="text-indigo-600"/> Thêm Thợ / Nhân Viên Mới
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
                    <div className="lg:col-span-1">
                        <label className="block text-xs font-bold text-slate-500 mb-1">Tên (Nick Name)</label>
                        <input 
                            value={newName} 
                            onChange={e => setNewName(e.target.value)} 
                            className="w-full p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
                            placeholder="Ví dụ: Andy..." 
                        />
                    </div>
                    
                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Chức Vụ</label>
                        <select 
                            value={newRole} 
                            onChange={e => setNewRole(e.target.value as StaffRole)}
                            className="w-full p-2.5 border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="Technician">Thợ (Tech)</option>
                            <option value="Manager">Quản Lý</option>
                            <option value="Owner">Chủ (Owner)</option>
                            <option value="Receptionist">Lễ Tân</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Loại Hợp Đồng</label>
                        <select 
                            value={newEmpType} 
                            onChange={e => setNewEmpType(e.target.value as any)}
                            className="w-full p-2.5 border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                        >
                            <option value="Contract">1099 (Thợ Khoán)</option>
                            <option value="W2">W-2 (Nhân Viên)</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Ăn Chia (%)</label>
                        <div className="relative">
                            <input 
                                type="number" 
                                value={newCommission} 
                                onChange={e => setNewCommission(e.target.value)} 
                                className="w-full p-2.5 pl-8 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-emerald-600" 
                                placeholder="60"
                            />
                            <BadgePercent size={14} className="absolute left-2.5 top-3.5 text-emerald-500" />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Trả Check (%)</label>
                        <div className="relative">
                            <input 
                                type="number" 
                                value={newCheckRate} 
                                onChange={e => setNewCheckRate(e.target.value)} 
                                className="w-full p-2.5 pl-8 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-600" 
                                placeholder="80"
                            />
                            <Wallet size={14} className="absolute left-2.5 top-3.5 text-indigo-500" />
                        </div>
                    </div>
                </div>
                <button 
                    onClick={addStaff} 
                    className="w-full mt-4 bg-slate-900 text-white py-3 rounded-lg font-bold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
                >
                    <Plus size={18}/> Thêm Nhân Viên
                </button>
            </div>

            {/* Staff List Management */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-slate-700">
                    Danh Sách Nhân Viên Hiện Tại
                </div>
                <div className="divide-y divide-slate-100">
                    {staffList.map(s => (
                         <div key={s.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                             <div className="flex items-center gap-3">
                                 <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                                     <User size={20}/>
                                 </div>
                                 <div>
                                     <div className="font-bold text-slate-800 flex items-center gap-2">
                                         {s.name}
                                         {s.employmentType === 'W2' ? 
                                            <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 rounded border border-purple-200">W-2</span> : 
                                            <span className="text-[10px] bg-orange-100 text-orange-700 px-1.5 rounded border border-orange-200">1099</span>
                                         }
                                     </div>
                                     <div className="text-xs text-slate-500 flex items-center gap-2">
                                         <span className="px-1.5 py-0.5 bg-slate-100 rounded border border-slate-200">{s.role}</span>
                                         <span>•</span>
                                         <span>Comm: {s.commissionRate * 100}%</span>
                                         <span>•</span>
                                         <span>Check: {s.checkPayoutRate * 100}%</span>
                                     </div>
                                 </div>
                             </div>
                             <button 
                                onClick={() => removeStaff(s.id)}
                                className="p-2 text-rose-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                title="Xóa"
                             >
                                 <Trash2 size={18}/>
                             </button>
                         </div>
                    ))}
                    {staffList.length === 0 && (
                        <div className="p-8 text-center text-slate-400">Danh sách trống</div>
                    )}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
