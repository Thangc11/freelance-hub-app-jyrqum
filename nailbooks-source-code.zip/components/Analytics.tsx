
import React, { useState, useMemo } from 'react';
import { Transaction, AppSettings, Staff } from '../types';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { getBusinessInsights } from '../services/geminiService';
import { Sparkles, TrendingUp, TrendingDown, DollarSign, PieChart as PieIcon, Filter, Calculator, Banknote, CreditCard, Users, Briefcase } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  settings: AppSettings;
  staffList: Staff[]; // Added staffList for payroll calculation
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];

export const Analytics: React.FC<Props> = ({ transactions, staffList }) => {
  const [aiResponse, setAiResponse] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Date Filter State
  const [dateRange, setDateRange] = useState<'THIS_MONTH' | 'LAST_MONTH' | 'THIS_YEAR' | 'CUSTOM'>('THIS_MONTH');
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); 
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

  // --- DATA PROCESSING ---
  const filteredData = useMemo(() => {
    let start = new Date(startDate);
    let end = new Date(endDate);
    const now = new Date();

    if (dateRange === 'THIS_MONTH') {
        start = new Date(now.getFullYear(), now.getMonth(), 1);
        end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    } else if (dateRange === 'LAST_MONTH') {
        start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        end = new Date(now.getFullYear(), now.getMonth(), 0);
    } else if (dateRange === 'THIS_YEAR') {
        start = new Date(now.getFullYear(), 0, 1);
        end = new Date(now.getFullYear(), 11, 31);
    }

    // Update state dates for display if not custom
    // Note: In a real app, use separate display state vs logic state to avoid render loops, 
    // but here we just use the memoized data.

    return transactions.filter(t => {
        const tDate = new Date(t.date);
        tDate.setHours(0,0,0,0); 
        const s = new Date(start); s.setHours(0,0,0,0);
        const e = new Date(end); e.setHours(23,59,59,999);
        return tDate >= s && tDate <= e;
    });
  }, [transactions, dateRange, startDate, endDate]);

  // --- FINANCIAL CALCULATIONS (From ExpensesReport) ---
  const fin = useMemo(() => {
    const incomeTx = filteredData.filter(t => t.type === 'INCOME');
    const expenseTx = filteredData.filter(t => t.type === 'EXPENSE');

    // 1. REVENUE
    const revenueCash = incomeTx.reduce((sum, t) => sum + (t.paymentSplit ? t.paymentSplit.cash : (t.paymentMethod === 'CASH' ? t.amount : 0)), 0);
    const revenueBank = incomeTx.reduce((sum, t) => sum + (t.paymentSplit ? t.paymentSplit.card : (t.paymentMethod !== 'CASH' ? t.amount : 0)), 0);
    
    // 2. EXPENSES
    const expenseCash = expenseTx.reduce((sum, t) => sum + (t.paymentSplit ? t.paymentSplit.cash : (t.paymentMethod === 'CASH' ? t.amount : 0)), 0);
    const expenseBank = expenseTx.reduce((sum, t) => sum + (t.paymentSplit ? t.paymentSplit.card : (t.paymentMethod !== 'CASH' ? t.amount : 0)), 0);

    // 3. PAYROLL ESTIMATION
    let payrollCash = 0;
    let payrollCheck = 0;
    let payrollW2 = 0;
    let payroll1099 = 0;

    staffList.forEach(staff => {
        let totalService = 0;
        let totalTips = 0;

        incomeTx.forEach(t => {
            if (t.staffDetails && t.staffDetails.length > 0) {
                 const detail = t.staffDetails.find(d => d.staffId === staff.id);
                 if (detail) { totalService += detail.amount; totalTips += detail.tip; }
            } else if (t.staffIds?.includes(staff.id)) {
                const split = t.staffIds.length;
                totalService += (t.amount / split);
                totalTips += ((t.tip || 0) / split);
            }
        });

        const commissionAmt = totalService * staff.commissionRate;
        const checkRate = staff.checkPayoutRate ?? 0.8;
        const cashRate = 1 - checkRate;

        // Payouts
        const payCheck = (commissionAmt * checkRate) + totalTips; // Tips usually go to check
        const payCash = (commissionAmt * cashRate);

        payrollCheck += payCheck;
        payrollCash += payCash;

        if (staff.employmentType === 'W2') payrollW2 += (payCheck + payCash);
        else payroll1099 += (payCheck + payCash);
    });

    return {
        revenueCash, revenueBank, totalRevenue: revenueCash + revenueBank,
        expenseCash, expenseBank, totalExpense: expenseCash + expenseBank,
        payrollCash, payrollCheck, totalPayroll: payrollCash + payrollCheck,
        payrollW2, payroll1099,
        remainingCash: revenueCash - expenseCash - payrollCash,
        remainingBank: revenueBank - expenseBank - payrollCheck,
        netProfit: (revenueCash + revenueBank) - (expenseCash + expenseBank) - (payrollCash + payrollCheck)
    };
  }, [filteredData, staffList]);

  // --- CHART DATA ---
  const trendData = useMemo(() => {
      const map = new Map<string, { date: string, income: number, expense: number }>();
      filteredData.forEach(t => {
          const d = t.date.split('T')[0];
          if (!map.has(d)) map.set(d, { date: d, income: 0, expense: 0 });
          const curr = map.get(d)!;
          if (t.type === 'INCOME') curr.income += t.amount;
          else curr.expense += t.amount;
      });
      return Array.from(map.values()).sort((a, b) => a.date.localeCompare(b.date));
  }, [filteredData]);

  const incomeCatData = useMemo(() => {
      const map = new Map<string, number>();
      filteredData.filter(t => t.type === 'INCOME').forEach(t => map.set(t.category, (map.get(t.category) || 0) + t.amount));
      return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
  }, [filteredData]);

  const handleAskAI = async () => {
    setLoading(true);
    const summary = {
        financials: fin,
        topIncome: incomeCatData.sort((a,b) => b.value - a.value)[0],
    };
    const res = await getBusinessInsights(JSON.stringify(summary), "Phân tích tình hình tài chính, dòng tiền mặt vs ngân hàng, và gợi ý cách tối ưu lợi nhuận.");
    setAiResponse(res || 'Không thể phân tích lúc này.');
    setLoading(false);
  };

  const fmt = (val: number) => `$${val.toLocaleString('en-US', {maximumFractionDigits: 0})}`;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* --- HEADER & FILTERS --- */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2">
              <div className="bg-slate-900 text-white p-2 rounded-lg"><TrendingUp size={20}/></div>
              <div>
                  <h2 className="text-lg font-bold text-slate-800">Báo Cáo Tài Chính (Financials)</h2>
                  <p className="text-xs text-slate-500">Tổng hợp doanh thu, chi phí & lợi nhuận</p>
              </div>
          </div>
          
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg">
              {(['THIS_MONTH', 'LAST_MONTH', 'THIS_YEAR'] as const).map(r => (
                  <button key={r} onClick={() => setDateRange(r)} className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${dateRange === r ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                      {r === 'THIS_MONTH' ? 'Tháng Này' : r === 'LAST_MONTH' ? 'Tháng Trước' : 'Năm Nay'}
                  </button>
              ))}
              <button onClick={() => setDateRange('CUSTOM')} className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${dateRange === 'CUSTOM' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Tùy Chọn</button>
          </div>
      </div>
      
      {dateRange === 'CUSTOM' && (
          <div className="bg-white p-3 rounded-lg border border-slate-200 flex justify-end gap-2 text-sm">
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="border p-1 rounded"/>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="border p-1 rounded"/>
          </div>
      )}

      {/* --- KPI CARDS --- */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="text-slate-500 text-xs font-bold uppercase mb-1 flex items-center gap-1"><TrendingUp size={14} className="text-emerald-500"/> Tổng Doanh Thu</div>
              <div className="text-2xl font-black text-slate-800">{fmt(fin.totalRevenue)}</div>
              <div className="text-[10px] text-slate-400 mt-1">Cash: {fmt(fin.revenueCash)} | Bank: {fmt(fin.revenueBank)}</div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="text-slate-500 text-xs font-bold uppercase mb-1 flex items-center gap-1"><TrendingDown size={14} className="text-rose-500"/> Tổng Chi Phí</div>
              <div className="text-2xl font-black text-slate-800">{fmt(fin.totalExpense)}</div>
              <div className="text-[10px] text-slate-400 mt-1">Rent, Supply, Utilities...</div>
          </div>
           <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="text-slate-500 text-xs font-bold uppercase mb-1 flex items-center gap-1"><Users size={14} className="text-orange-500"/> Tổng Lương (Est)</div>
              <div className="text-2xl font-black text-slate-800">{fmt(fin.totalPayroll)}</div>
              <div className="text-[10px] text-slate-400 mt-1">W-2: {fmt(fin.payrollW2)} | 1099: {fmt(fin.payroll1099)}</div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="text-slate-500 text-xs font-bold uppercase mb-1 flex items-center gap-1"><DollarSign size={14} className="text-indigo-500"/> Lợi Nhuận Ròng</div>
              <div className={`text-2xl font-black ${fin.netProfit >= 0 ? 'text-indigo-600' : 'text-rose-600'}`}>{fmt(fin.netProfit)}</div>
              <div className="text-[10px] text-slate-400 mt-1">Margin: {fin.totalRevenue ? ((fin.netProfit/fin.totalRevenue)*100).toFixed(1) : 0}%</div>
          </div>
      </div>

      {/* --- CHART SECTION --- */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-[350px]">
          <h3 className="font-bold text-slate-700 mb-4 text-sm uppercase tracking-wide">Biểu Đồ Doanh Thu & Chi Phí (Ngày)</h3>
          <ResponsiveContainer width="100%" height="90%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="date" fontSize={11} tickFormatter={val => val.slice(5)}/>
              <YAxis fontSize={11} tickFormatter={(val) => `$${val/1000}k`}/>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0"/>
              <Tooltip formatter={(value: number) => fmt(value)}/>
              <Area type="monotone" dataKey="income" name="Thu" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" />
              <Area type="monotone" dataKey="expense" name="Chi" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorExpense)" />
              <Legend verticalAlign="top" height={36}/>
            </AreaChart>
          </ResponsiveContainer>
      </div>

      {/* --- DETAILED P&L TABLE (CASH FLOW) --- */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* CASH FLOW CARD */}
           <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
               <div className="bg-emerald-50/50 p-4 border-b border-emerald-100 flex items-center gap-3">
                   <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Banknote size={20} /></div>
                   <h3 className="font-bold text-emerald-900 text-sm uppercase">Dòng Tiền Mặt (Cash)</h3>
               </div>
               <div className="p-5 space-y-3 text-sm">
                   <div className="flex justify-between text-slate-600">
                       <span>Thu (Tiền mặt):</span>
                       <span className="font-bold text-emerald-600">+{fmt(fin.revenueCash)}</span>
                   </div>
                   <div className="flex justify-between text-slate-500">
                       <span>- Chi Phí Vận Hành (Cash):</span>
                       <span>-{fmt(fin.expenseCash)}</span>
                   </div>
                   <div className="flex justify-between text-slate-500">
                       <span>- Trả Lương (Cash):</span>
                       <span>-{fmt(fin.payrollCash)}</span>
                   </div>
                   <div className="pt-3 border-t border-slate-100 flex justify-between font-black text-lg text-slate-800">
                       <span>Thực Tế Cầm Tay:</span>
                       <span>{fmt(fin.remainingCash)}</span>
                   </div>
               </div>
           </div>

           {/* BANK FLOW CARD */}
           <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
               <div className="bg-indigo-50/50 p-4 border-b border-indigo-100 flex items-center gap-3">
                   <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><CreditCard size={20} /></div>
                   <h3 className="font-bold text-indigo-900 text-sm uppercase">Ngân Hàng / Check (Bank)</h3>
               </div>
               <div className="p-5 space-y-3 text-sm">
                   <div className="flex justify-between text-slate-600">
                       <span>Thu (Thẻ/Check):</span>
                       <span className="font-bold text-indigo-600">+{fmt(fin.revenueBank)}</span>
                   </div>
                   <div className="flex justify-between text-slate-500">
                       <span>- Chi Phí Vận Hành (Bank):</span>
                       <span>-{fmt(fin.expenseBank)}</span>
                   </div>
                   <div className="flex justify-between text-slate-500">
                       <span>- Trả Lương (Check):</span>
                       <span>-{fmt(fin.payrollCheck)}</span>
                   </div>
                   <div className="pt-3 border-t border-slate-100 flex justify-between font-black text-lg text-slate-800">
                       <span>Dư Trong Bank:</span>
                       <span>{fmt(fin.remainingBank)}</span>
                   </div>
               </div>
           </div>
      </div>

      {/* --- AI ADVICE SECTION --- */}
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100 shadow-sm">
        <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-indigo-800 font-bold">
                <div className="bg-white p-2 rounded-full shadow-sm"><Sparkles size={20} className="text-indigo-600" /></div>
                <span>Trợ Lý Tài Chính AI</span>
            </div>
            {!aiResponse && (
                <button onClick={handleAskAI} disabled={loading} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-xs font-bold shadow-lg shadow-indigo-200 transition-all active:scale-95 disabled:opacity-50">
                    {loading ? "Đang suy nghĩ..." : "Phân tích ngay"}
                </button>
            )}
        </div>
        {aiResponse ? (
            <div className="bg-white/80 p-5 rounded-xl border border-indigo-50 text-slate-700 text-sm leading-relaxed whitespace-pre-wrap animate-fade-in shadow-sm">{aiResponse}</div>
        ) : (
            <p className="text-xs text-indigo-400 pl-1">Bấm nút để AI phân tích sức khỏe tài chính và gợi ý tối ưu thuế.</p>
        )}
      </div>
    </div>
  );
};
