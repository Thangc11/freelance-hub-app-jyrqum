
import React, { useRef, useState } from 'react';
import { Transaction, Staff, AppSettings } from '../types';
import { Trash2, Download, Upload, Code, FileCode, AlertTriangle, CheckCircle, Loader2, Share, PlusSquare, Smartphone } from 'lucide-react';
import JSZip from 'jszip';
import saveAs from 'file-saver';

interface Props {
  data: { transactions: Transaction[], staffList: Staff[], settings: AppSettings };
  onImport: (data: any) => void;
  onReset: () => void;
}

export const SettingsAndData: React.FC<Props> = ({ data, onImport, onReset }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const [downloadingSource, setDownloadingSource] = useState(false);

  // --- DATA BACKUP ---
  const downloadBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nailbooks-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
  };

  const uploadBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const json = JSON.parse(evt.target?.result as string);
        if(confirm("Khôi phục dữ liệu sẽ xóa dữ liệu hiện tại?")) {
          onImport(json);
        }
      } catch(err) { alert("File lỗi"); }
    };
    reader.readAsText(file);
  };

  // --- SOURCE CODE DOWNLOAD ---
  const handleDownloadSource = async () => {
    setDownloadingSource(true);
    try {
        const zip = new JSZip();

        const packageJson = {
            "name": "nailbooks-ai",
            "version": "1.0.0",
            "description": "Smart AI Bookkeeping for Nail Salons",
            "main": "index.tsx",
            "dependencies": {
                "react": "^18.3.1",
                "react-dom": "^18.3.1",
                "lucide-react": "^0.263.1",
                "@google/genai": "^1.42.0",
                "recharts": "^2.12.0",
                "jszip": "^3.10.1",
                "file-saver": "^2.0.5"
            }
        };
        zip.file("package.json", JSON.stringify(packageJson, null, 2));

        const filesToFetch = [
            'index.html', 'index.tsx', 'App.tsx', 'types.ts', 'constants.ts', 'manifest.json', 'service-worker.js',
            'services/geminiService.ts', 'components/SummaryCards.tsx', 'components/TransactionForm.tsx', 
            'components/TransactionsList.tsx', 'components/StaffManager.tsx', 'components/Analytics.tsx', 
            'components/TaxPrep.tsx', 'components/SettingsAndData.tsx'
        ];

        let successCount = 0;
        for (const file of filesToFetch) {
            try {
                const response = await fetch(`./${file}`);
                if (response.ok) {
                    const content = await response.text();
                    zip.file(file, content);
                    successCount++;
                } else {
                    zip.file(file, `// Could not fetch ${file}.`);
                }
            } catch (e) { console.warn(e); }
        }

        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, "nailbooks-source-code.zip");
    } catch (error) {
        alert("Có lỗi khi tạo file nén.");
        console.error(error);
    } finally {
        setDownloadingSource(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* IOS INSTALL GUIDE */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-6 rounded-xl border border-blue-800 shadow-md">
         <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
             <Smartphone size={24}/> Cài Đặt Trên iPhone (App)
         </h3>
         <div className="flex flex-col md:flex-row gap-6">
             <div className="space-y-3 text-blue-100 text-sm">
                 <p>Để sử dụng App <strong>Offline</strong> và toàn màn hình như App tải từ Store:</p>
                 <ol className="list-decimal list-inside space-y-2 font-medium">
                     <li>Mở trang web này bằng trình duyệt <strong>Safari</strong>.</li>
                     <li className="flex items-center gap-1">Bấm nút chia sẻ <Share size={16} className="inline"/> ở thanh dưới cùng.</li>
                     <li className="flex items-center gap-1">Chọn <PlusSquare size={16} className="inline"/> <strong>"Add to Home Screen"</strong> (Thêm vào MH chính).</li>
                     <li>Đặt tên <strong>NailBooks</strong> và bấm Add.</li>
                 </ol>
             </div>
             <div className="hidden md:flex items-center justify-center bg-white/10 rounded-lg p-4">
                 <div className="text-center">
                    <div className="text-2xl font-bold mb-1">NailBooks</div>
                    <div className="text-[10px] opacity-70">App Icon Preview</div>
                 </div>
             </div>
         </div>
      </div>

      {/* DATA MANAGEMENT */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Upload size={20} className="text-slate-500"/> Quản Lý Dữ Liệu (Backup)
        </h3>
        <p className="text-sm text-slate-500">Sao lưu dữ liệu về máy để tránh mất mát khi đổi trình duyệt hoặc xóa cache.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button onClick={downloadBackup} className="flex items-center justify-center gap-2 p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-medium text-slate-700">
            <Download size={20} className="text-indigo-600"/> Tải Dữ Liệu (.json)
          </button>
          
          <button onClick={() => fileRef.current?.click()} className="flex items-center justify-center gap-2 p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-medium text-slate-700">
            <Upload size={20} className="text-emerald-600"/> Khôi Phục Dữ Liệu
            <input type="file" className="hidden" ref={fileRef} onChange={uploadBackup} accept=".json"/>
          </button>
        </div>
      </div>

      {/* DEVELOPER ZONE */}
      <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <Code size={100} />
        </div>
        
        <h3 className="font-bold text-lg mb-2 flex items-center gap-2 relative z-10">
            <FileCode size={24} className="text-emerald-400"/> Dành Cho Developer
        </h3>
        <p className="text-slate-300 text-sm mb-6 max-w-lg relative z-10">
            Tải trọn bộ mã nguồn (Source Code) của ứng dụng này để triển khai trên hosting riêng.
        </p>

        <button 
            onClick={handleDownloadSource} 
            disabled={downloadingSource}
            className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 rounded-lg font-bold shadow-lg shadow-emerald-900/20 transition-all flex items-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed relative z-10 active:scale-95"
        >
            {downloadingSource ? (
                <>
                    <Loader2 size={20} className="animate-spin"/> Đang nén file...
                </>
            ) : (
                <>
                    <Download size={20}/> Tải Source Code (.zip)
                </>
            )}
        </button>
      </div>

      {/* DANGER ZONE */}
      <div className="pt-8 border-t border-slate-200">
        <button onClick={onReset} className="w-full p-4 bg-rose-50 text-rose-600 font-bold rounded-xl flex justify-center items-center gap-2 hover:bg-rose-100 transition-colors border border-rose-100">
          <Trash2 size={20}/> Xóa Trắng Toàn Bộ Dữ Liệu (Reset App)
        </button>
        <p className="text-center text-xs text-rose-300 mt-2">Hành động này không thể hoàn tác.</p>
      </div>
    </div>
  );
};
