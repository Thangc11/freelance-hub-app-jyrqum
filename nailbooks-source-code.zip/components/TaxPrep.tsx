
import React, { useState, useMemo } from 'react';
import { Transaction, Staff } from '../types';
import { getBusinessInsights } from '../services/geminiService';
import { Calculator, FileText, Users, CheckCircle, Search, ScrollText, Printer, Calendar, ShieldCheck, AlertCircle } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  staffList: Staff[];
}

export const TaxPrep: React.FC<Props> = ({ transactions, staffList }) => {
  const [year, setYear] = useState(new Date().getFullYear());
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiAdvice, setAiAdvice] = useState('');

  // --- DATA PROCESSING ---
  const data = useMemo(() => transactions.filter(t => new Date(t.date).getFullYear() === year), [transactions, year]);
  const incomeTx = data.filter(t => t.type === 'INCOME');
  const expenseTx = data.filter(t => t.type === 'EXPENSE');

  const totalGrossReceipts = incomeTx.reduce((sum, t) => sum + t.amount, 0);
  
  // Mapping Expenses to Schedule C
  const expensesMap = useMemo<Record<string, number>>(() => {
    const map: Record<string, number> = {
        'Advertising': 0, 'Contract Labor': 0, 'Legal & Professional': 0, 'Office Expense': 0,
        'Rent or Lease': 0, 'Repairs & Maintenance': 0, 'Supplies (Not COGS)': 0,
        'Taxes & Licenses': 0, 'Travel & Meals': 0, 'Wages (W-2)': 0, 'Other Expenses': 0
    };

    expenseTx.forEach(t => {
        switch (t.category) {
            case 'Marketing & Ads': map['Advertising'] += t.amount; break;
            case 'Tiền Thuê (Rent/Office)': map['Rent or Lease'] += t.amount; break;
            case 'Phần Mềm & Tiện Ích (SaaS/Utilities)': map['Office Expense'] += t.amount; break;
            case 'Bảo Trì & Sửa Chữa': map['Repairs & Maintenance'] += t.amount; break;
            case 'Nhập Hàng (COGS)': map['Supplies (Not COGS)'] += t.amount; break;
            case 'Đi Lại & Ăn Uống (Travel/Meals)': map['Travel & Meals'] += t.amount; break;
            case 'Thuế (Tax)': map['Taxes & Licenses'] += t.amount; break;
            case 'Lương Nhân Viên (Payroll)': map['Wages (W-2)'] += t.amount; break;
            default: map['Other Expenses'] += t.amount;
        }
    });

    let calcContractLabor = 0;
    let calcWages = 0;

    staffList.forEach(s => {
        let totalPaid = 0;
        incomeTx.forEach(t => {
            if (t.staffDetails) {
                const d = t.staffDetails.find(det => det.staffId === s.id);
                if (d) totalPaid += (d.amount * s.commissionRate);
            } else if (t.staffIds?.includes(s.id)) {
                 const split = t.staffIds.length;
                 totalPaid += ((t.amount/split) * s.commissionRate);
            }
        });
        if (s.employmentType === 'W2') calcWages += totalPaid;
        else calcContractLabor += totalPaid;
    });

    if (map['Contract Labor'] === 0) map['Contract Labor'] = calcContractLabor;
    if (map['Wages (W-2)'] === 0) map['Wages (W-2)'] = calcWages;

    return map;
  }, [expenseTx, incomeTx, staffList]);

  const totalDeductions = (Object.values(expensesMap) as number[]).reduce((a, b) => a + b, 0);
  const netProfit = totalGrossReceipts - totalDeductions;
  
  // Tax Estimations
  const seTax = (netProfit * 0.9235) * 0.153; 
  const estIncomeTax = netProfit > 12000 ? (netProfit - 12000) * 0.15 : 0; 
  const totalEstTax = seTax + estIncomeTax;

  const candidates1099 = useMemo(() => {
      return staffList.map(s => {
          let total = 0;
          incomeTx.forEach(t => {
             if (t.staffDetails) {
                const d = t.staffDetails.find(det => det.staffId === s.id);
                if (d) total += (d.amount * s.commissionRate); 
             }
          });
          return { ...s, totalPaid: total };
      }).filter(s => s.totalPaid >= 600 && s.employmentType !== 'W2').sort((a,b) => b.totalPaid - a.totalPaid);
  }, [staffList, incomeTx]);

  const handleAuditAI = async () => {
      setLoadingAI(true);
      const summary = JSON.stringify({ grossRevenue: totalGrossReceipts, expenses: expensesMap, netProfit: netProfit, businessType: "Nail Salon" });
      const prompt = "Act as a CPA for a Nail Salon. Review these Schedule C figures. 1) Are the expense ratios normal? 2) Suggest missed deductions specifically for nail salons. 3) Flag audit risks. Answer in Vietnamese.";
      const res = await getBusinessInsights(summary, prompt);
      setAiAdvice(res || "AI đang bận, thử lại sau.");
      setLoadingAI(false);
  };

  const fmt = (n: number) => `$${n.toLocaleString('en-US', {maximumFractionDigits: 0})}`;

  // --- DEDUCTION CHECKLIST COMPONENT ---
  const DeductionItem = ({ title, desc }: {title: string, desc: string}) => (
      <div className="flex items-start gap-3 p-3 bg-white rounded-lg border border-slate-100 hover:border-indigo-200 transition-colors">
          <CheckCircle size={18} className="text-emerald-500 mt-0.5 shrink-0"/>
          <div>
              <div className="font-bold text-slate-800 text-sm">{title}</div>
              <div className="text-xs text-slate-500">{desc}</div>
          </div>
      </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* HEADER */}
      <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2">
              <div className="bg-slate-900 text-white p-2 rounded-lg"><ShieldCheck size={20}/></div>
              <div>
                  <h2 className="font-bold text-slate-800 text-lg">Trung Tâm Thuế (Tax Center)</h2>
                  <p className="text-xs text-slate-500">Chuẩn bị hồ sơ, tối ưu thuế & tránh rủi ro</p>
              </div>
          </div>
          <select value={year} onChange={(e) => setYear(parseInt(e.target.value))} className="font-bold bg-slate-100 border border-slate-200 rounded px-3 py-1 text-slate-800 outline-none">
              {[2023, 2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* LEFT COLUMN: NUMBERS */}
          <div className="lg:col-span-2 space-y-6">
              {/* ESTIMATED TAX CARD */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 mb-4 text-slate-700 font-bold">
                      <Calculator size={20} className="text-rose-500"/>
                      <h3>Dự Tính Thuế (Estimated Tax)</h3>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                      <div>
                          <div className="text-xs text-slate-500 font-bold uppercase">Lợi Nhuận Ròng (Net)</div>
                          <div className="text-2xl font-black text-slate-800">{fmt(netProfit)}</div>
                      </div>
                      <div className="text-right">
                          <div className="text-xs text-slate-500 font-bold uppercase">Cần Để Dành (Est)</div>
                          <div className="text-2xl font-black text-rose-600">{fmt(totalEstTax)}</div>
                          <div className="text-[10px] text-slate-400">SE Tax + Income Tax (~30%)</div>
                      </div>
                  </div>
              </div>

              {/* SCHEDULE C TABLE */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-slate-800 flex items-center gap-2"><ScrollText size={20} className="text-indigo-600"/> Schedule C Draft</h3>
                      <button onClick={() => window.print()} className="text-xs font-bold text-slate-500 hover:text-indigo-600 flex items-center gap-1"><Printer size={14}/> In</button>
                  </div>
                  <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                          <tbody className="divide-y divide-slate-100">
                              {Object.entries(expensesMap).map(([key, val]: [string, number]) => (
                                  val > 0 && (
                                      <tr key={key} className="hover:bg-slate-50">
                                          <td className="py-2 text-slate-700 font-medium">{key}</td>
                                          <td className="py-2 text-right font-bold text-slate-900">{fmt(val)}</td>
                                          <td className="py-2 text-right text-slate-400 text-xs w-16">{totalGrossReceipts > 0 ? ((val/totalGrossReceipts)*100).toFixed(1) : 0}%</td>
                                      </tr>
                                  )
                              ))}
                              <tr className="bg-slate-50 font-bold">
                                  <td className="py-3 text-slate-800">Total Expenses</td>
                                  <td className="py-3 text-right text-slate-900">{fmt(totalDeductions)}</td>
                                  <td></td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
              </div>

              {/* 1099 LIST */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <h3 className="font-bold text-slate-800 flex items-center gap-2 mb-4"><Users size={20} className="text-orange-500"/> Danh Sách Cần 1099-NEC</h3>
                  <div className="space-y-2">
                      {candidates1099.map((s, idx) => (
                          <div key={s.id} className="flex justify-between items-center p-2 border-b border-slate-100 last:border-0">
                              <span className="text-sm font-medium text-slate-700">{idx+1}. {s.name} <span className="text-[10px] text-slate-400">({s.role})</span></span>
                              <span className="text-sm font-bold text-orange-600">{fmt(s.totalPaid)}</span>
                          </div>
                      ))}
                      {candidates1099.length === 0 && <p className="text-sm text-slate-400 italic">Không có ai cần xuất 1099.</p>}
                  </div>
              </div>
          </div>

          {/* RIGHT COLUMN: RECOMMENDATIONS & AI */}
          <div className="space-y-6">
              {/* AI CARD */}
              <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-6 rounded-xl shadow-lg text-white relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-4 opacity-20"><Search size={80}/></div>
                   <h3 className="font-bold text-lg mb-2 relative z-10 flex items-center gap-2"><Search size={20}/> AI Tax Audit</h3>
                   <p className="text-indigo-100 text-sm mb-4 relative z-10">AI đóng vai CPA kiểm tra rủi ro thuế và tìm khoản khấu trừ bị sót.</p>
                   
                   {!aiAdvice ? (
                       <button onClick={handleAuditAI} disabled={loadingAI} className="w-full bg-white text-indigo-700 font-bold py-2 rounded-lg text-sm shadow-md hover:bg-indigo-50 transition-colors relative z-10">
                           {loadingAI ? 'Đang kiểm tra...' : 'Bắt Đầu Kiểm Tra'}
                       </button>
                   ) : (
                       <div className="bg-white/10 p-3 rounded-lg text-xs leading-relaxed max-h-[200px] overflow-y-auto custom-scrollbar relative z-10 border border-white/20">
                           {aiAdvice}
                       </div>
                   )}
              </div>

              {/* TAX CALENDAR */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                  <h3 className="font-bold text-slate-800 mb-3 flex items-center gap-2"><Calendar size={18} className="text-slate-500"/> Lịch Đóng Thuế (Est)</h3>
                  <div className="space-y-3">
                      {[
                          {date: '15/04', label: 'Q1 Payment (Jan-Mar)'},
                          {date: '15/06', label: 'Q2 Payment (Apr-May)'},
                          {date: '15/09', label: 'Q3 Payment (Jun-Aug)'},
                          {date: '15/01', label: 'Q4 Payment (Sep-Dec)'},
                      ].map((item, i) => (
                          <div key={i} className="flex items-center justify-between text-sm">
                              <span className="font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded text-xs">{item.date}</span>
                              <span className="text-slate-600 text-xs">{item.label}</span>
                          </div>
                      ))}
                  </div>
              </div>

              {/* TOP DEDUCTIONS */}
              <div className="bg-slate-50 p-5 rounded-xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4 text-sm uppercase tracking-wide">Top Khấu Trừ Tiệm Nail (Checklist)</h3>
                  <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                      <DeductionItem title="Rent & Utilities" desc="Tiền thuê tiệm, điện, nước, internet, rác."/>
                      <DeductionItem title="Supplies & Materials" desc="Sơn, kềm, dũa, acetone, khăn, găng tay."/>
                      <DeductionItem title="Contract Labor (1099)" desc="Tiền trả thợ khoán (lưu giữ Check/Log)."/>
                      <DeductionItem title="Repairs & Maintenance" desc="Sửa ghế spa, sơn sửa tiệm, bóng đèn."/>
                      <DeductionItem title="Advertising" desc="Facebook Ads, in menu, business cards, website."/>
                      <DeductionItem title="Licenses & Permits" desc="License tiệm, license thợ, city permit."/>
                      <DeductionItem title="Insurance" desc="Bảo hiểm tiệm (Liability, Worker's Comp)."/>
                      <DeductionItem title="Meals (50%)" desc="Ăn uống bàn công việc với thợ/partner."/>
                      <DeductionItem title="Uniforms & Laundry" desc="Đồng phục có logo, giặt ủi khăn."/>
                      <DeductionItem title="Software & Subscriptions" desc="Phần mềm POS, NailBooks App, Spotify nhạc."/>
                      <DeductionItem title="Bank & Merchant Fees" desc="Phí máy thẻ, phí ngân hàng hàng tháng."/>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};
