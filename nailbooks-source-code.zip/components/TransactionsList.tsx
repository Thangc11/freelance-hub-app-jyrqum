
import React, { useState } from 'react';
import { Transaction, Staff } from '../types';
import { Trash2, User, CreditCard, Banknote, Building2, Coins, Receipt, Wallet, Calculator, Filter, Calendar } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  staffList: Staff[];
  onDelete: (id: string) => void;
}

export const TransactionsList: React.FC<Props> = ({ transactions, staffList, onDelete }) => {
  
  // Date Filter State
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // Mặc định đầu tháng
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Apply Filter
  const filteredTransactions = transactions.filter(t => {
      const tDate = t.date.split('T')[0];
      return tDate >= startDate && tDate <= endDate;
  });

  // --- CALCULATE TOTALS ---
  const incomeTx = filteredTransactions.filter(t => t.type === 'INCOME');
  
  const totalServiceCash = incomeTx.reduce((sum, t) => {
      const cashPart = t.paymentSplit ? t.paymentSplit.cash : (t.paymentMethod === 'CASH' ? t.amount : 0);
      return sum + cashPart;
  }, 0);

  const totalServiceCheck = incomeTx.reduce((sum, t) => {
      const cardPart = t.paymentSplit ? t.paymentSplit.card : (t.paymentMethod !== 'CASH' ? t.amount : 0);
      return sum + cardPart;
  }, 0);

  // -------------------------

  const getStaffBreakdown = (t: Transaction) => {
    // Staff details logic...
    if (t.staffDetails && t.staffDetails.length > 0) {
        return (
            <div className="flex flex-wrap gap-2 mt-2">
                {t.staffDetails.map((d, idx) => {
                    const s = staffList.find(staff => staff.id === d.staffId);
                    return (
                        <div key={idx} className="text-xs px-2 py-1 rounded-lg border border-slate-100 bg-slate-50 flex items-center gap-2 text-slate-600">
                             <div className="font-bold flex items-center gap-1">
                                <User size={10}/> {s?.name || 'Unknown'}
                             </div>
                             <span className="opacity-50">|</span>
                             <span>${d.amount}</span>
                             {d.tip > 0 && <span className="text-orange-500 font-bold">+${d.tip}</span>}
                        </div>
                    );
                })}
            </div>
        );
    }
    // Backward compatibility
    if (t.staffIds && t.staffIds.length > 0) {
        return (
             <div className="text-xs text-slate-400 mt-1">
                Thợ: {t.staffIds.map(id => staffList.find(s => s.id === id)?.name).join(', ')}
             </div>
        );
    }
    return null;
  };

  const getPaymentDisplay = (t: Transaction) => {
      // 1. Check if mixed split
      if (t.paymentSplit && t.paymentSplit.cash > 0 && t.paymentSplit.card > 0) {
          return (
              <div className="flex items-center gap-2 text-xs font-medium">
                  <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                      <Banknote size={12}/> ${t.paymentSplit.cash}
                  </span>
                  <span className="text-slate-300">/</span>
                  <span className="flex items-center gap-1 text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                      <CreditCard size={12}/> ${t.paymentSplit.card}
                  </span>
              </div>
          );
      }
      
      // 2. Single Payment
      let icon = <CreditCard size={12}/>;
      let colorClass = "text-indigo-600 bg-indigo-50";
      let label: string = t.paymentMethod;

      if (t.paymentMethod === 'CASH') {
          icon = <Banknote size={12}/>;
          colorClass = "text-emerald-600 bg-emerald-50";
          label = 'Cash';
      } else if (t.paymentMethod === 'BANK_TRANSFER') {
          icon = <Building2 size={12}/>;
          label = 'Bank';
      } else if (t.paymentMethod === 'CHECK') {
          label = 'Check';
      } else if (t.paymentMethod === 'CREDIT') {
          label = 'Credit';
      }

      return (
          <span className={`text-xs font-bold flex items-center gap-1 px-2 py-0.5 rounded ${colorClass}`}>
              {icon} {label}
          </span>
      );
  };

  return (
    <div className="space-y-4">
      {/* --- FILTER BAR --- */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
         <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
             <Filter size={14}/> Bộ Lọc (Filter)
         </div>
         <div className="flex items-center gap-2">
            <input 
                type="date" 
                value={startDate} 
                onChange={e => setStartDate(e.target.value)} 
                className="text-sm font-medium bg-slate-50 border border-slate-200 rounded px-2 py-1 outline-none text-slate-700"
            />
            <span className="text-slate-400 text-xs">➝</span>
            <input 
                type="date" 
                value={endDate} 
                onChange={e => setEndDate(e.target.value)} 
                className="text-sm font-medium bg-slate-50 border border-slate-200 rounded px-2 py-1 outline-none text-slate-700"
            />
         </div>
      </div>

      {/* --- SUMMARY HEADER --- */}
      <div className="bg-slate-900 text-white p-4 rounded-xl shadow-lg flex flex-col md:flex-row justify-between items-center gap-4">
         <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
                <Calculator size={24} className="text-emerald-400"/>
            </div>
            <div>
                <h3 className="text-sm font-medium text-slate-300 uppercase tracking-wider">Tổng Doanh Thu (Filter)</h3>
                <div className="text-2xl font-black">${(totalServiceCash + totalServiceCheck).toLocaleString('en-US')}</div>
            </div>
         </div>

         <div className="flex gap-4">
            <div className="text-right">
                <div className="text-[10px] text-emerald-400 font-bold uppercase">Tiền Mặt</div>
                <div className="text-lg font-bold">${totalServiceCash.toLocaleString('en-US')}</div>
            </div>
            <div className="w-px bg-white/20 h-8"></div>
            <div className="text-right">
                <div className="text-[10px] text-indigo-400 font-bold uppercase">Thẻ / Bank</div>
                <div className="text-lg font-bold">${totalServiceCheck.toLocaleString('en-US')}</div>
            </div>
         </div>
      </div>

      {/* --- LIST --- */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 bg-slate-50 font-bold text-slate-700 border-b border-slate-200 flex justify-between items-center">
            <div className="flex items-center gap-2"><Receipt size={18}/> Chi Tiết Giao Dịch</div>
            <span className="text-xs font-normal text-slate-500">{filteredTransactions.length} items</span>
        </div>
        <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {filteredTransactions.map(t => (
            <div key={t.id} className="p-4 flex justify-between items-start hover:bg-slate-50 transition-colors group">
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${t.type === 'INCOME' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                            {t.category}
                        </span>
                        <span className="text-xs text-slate-400 font-medium">{new Date(t.date).toLocaleDateString()}</span>
                    </div>
                    
                    <div className="font-bold text-slate-800 text-sm mb-1">{t.description || 'Không có mô tả'}</div>
                    
                    {/* Payment Details Inline */}
                    <div className="flex items-center gap-3">
                        {getPaymentDisplay(t)}
                        
                        {(t.tip || 0) > 0 && (
                            <span className="flex items-center text-orange-600 font-bold text-xs bg-orange-50 px-2 py-0.5 rounded">
                                <Coins size={10} className="mr-1"/> ${t.tip} Tip
                            </span>
                        )}
                    </div>

                    {/* Staff Breakdown */}
                    {t.type === 'INCOME' && getStaffBreakdown(t)}
                </div>

                <div className="text-right pl-4">
                    <div className={`font-black text-lg ${t.type === 'INCOME' ? 'text-emerald-600' : 'text-slate-800'}`}>
                        {t.type === 'INCOME' ? '+' : '-'}${t.amount.toLocaleString('en-US')}
                    </div>
                    <button onClick={() => onDelete(t.id)} className="text-xs text-rose-300 hover:text-rose-600 opacity-0 group-hover:opacity-100 transition-opacity mt-2 font-bold flex items-center justify-end gap-1 w-full">
                        <Trash2 size={12}/> Xóa
                    </button>
                </div>
            </div>
            ))}
            {filteredTransactions.length === 0 && <div className="p-12 text-center text-slate-400">Không tìm thấy giao dịch nào trong khoảng thời gian này.</div>}
        </div>
      </div>
    </div>
  );
};
