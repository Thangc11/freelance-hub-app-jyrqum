
import React from 'react';
import { Transaction, Staff } from '../types';
import { TrendingUp, Users, Wallet, CreditCard } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  staffList: Staff[];
}

export const SummaryCards: React.FC<Props> = ({ transactions, staffList }) => {
  const incomeTx = transactions.filter(t => t.type === 'INCOME');
  const expenseTx = transactions.filter(t => t.type === 'EXPENSE');

  // 1. Total Revenue
  const totalRevenue = incomeTx.reduce((sum, t) => sum + t.amount, 0);
  
  // 2. Total Expense (Recorded Expenses)
  const totalRecordedExpense = expenseTx.reduce((sum, t) => sum + t.amount, 0);

  // 3. Calculated Payroll (Commissions + Tips)
  let commissionCost = 0;
  let totalTipsPayable = 0;

  incomeTx.forEach(t => {
    // New Logic
    if (t.staffDetails && t.staffDetails.length > 0) {
        t.staffDetails.forEach(d => {
            const staff = staffList.find(s => s.id === d.staffId);
            if (staff) {
                commissionCost += ((d.amount || 0) * staff.commissionRate);
                totalTipsPayable += (d.tip || 0);
            }
        });
    } 
    // Old Logic (Backward compatibility)
    else if (t.staffIds && t.staffIds.length > 0) {
      const split = t.staffIds.length;
      const amountPerHead = t.amount / split;
      const tipPerHead = (t.tip || 0) / split;
      
      t.staffIds.forEach(sid => {
        const staff = staffList.find(s => s.id === sid);
        if (staff) {
            commissionCost += (amountPerHead * staff.commissionRate);
            totalTipsPayable += tipPerHead;
        }
      });
    }
  });

  const totalPersonnelCost = commissionCost + totalTipsPayable;

  // 4. Net Profit (Revenue - Expense - Staff Cost)
  // Logic: Revenue (Service Only) - Expense - Tech Commission. (Tips are pass-through usually)
  const netProfit = totalRevenue - totalRecordedExpense - commissionCost;

  const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);

  const Card = ({ title, val, sub, icon: Icon, color }: any) => (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
      <div className="flex items-center gap-3 mb-2">
        <div className={`p-2 rounded-lg ${color} bg-opacity-10 text-opacity-100`}>
          <Icon size={20} />
        </div>
        <span className="text-slate-500 font-medium text-sm">{title}</span>
      </div>
      <div className="text-2xl font-bold text-slate-900">{fmt(val)}</div>
      <div className="text-xs text-slate-400 mt-1">{sub}</div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card title="Doanh Thu Service" val={totalRevenue} sub="Chưa bao gồm Tip" icon={TrendingUp} color="bg-emerald-600 text-emerald-700" />
      <Card title="Chi Phí Vận Hành" val={totalRecordedExpense} sub="Rent, Supply, etc" icon={CreditCard} color="bg-rose-600 text-rose-700" />
      <Card title="Chi Phí Nhân Sự" val={totalPersonnelCost} sub={`Gồm $${Math.round(totalTipsPayable)} Tip trả thợ`} icon={Users} color="bg-orange-600 text-orange-700" />
      <Card title="Lợi Nhuận Ròng" val={netProfit} sub="Revenue - Exp - Comm" icon={Wallet} color="bg-indigo-600 text-indigo-700" />
    </div>
  );
};
